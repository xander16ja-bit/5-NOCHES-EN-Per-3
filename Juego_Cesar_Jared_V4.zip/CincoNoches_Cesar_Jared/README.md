# 5 Noches con César y Jared — Versión 4.0 (fan game original)

Juego de vigilancia nocturna para Android, inspirado en el género de terror con cámaras. No incluye assets, música, personajes ni diálogos de FNAF.

## Novedades

- 5 llamadas originales con voz sintetizada en **español latino**, archivadas como MP3 locales: sin conexión a Internet.
- Dos botones nuevos de **LUZ**, uno para cada entrada, para descubrir quién está afuera.
- Seis cámaras, dos puertas, batería, pasos, interferencia y progresión de cinco noches.
- Apagón con luces intermitentes y acercamiento de siluetas.
- Sustos animados no gráficos.
- Instalación **junto** a versiones anteriores, porque se usa una identificación Android nueva (`com.cinconoches.cesaryjared.v4`).

## Cómo compilar desde Android + GitHub

1. Subir `Juego_Cesar_Jared_V4.zip` completo a la raíz de un repositorio privado nuevo o existente.
2. Crear o reemplazar `.github/workflows/generar-apk.yml` con el contenido del archivo `generar_apk_v4.yml` adjunto.
3. Guardar con Commit changes. Ir a Actions → Generar APK 5 Noches V4.
4. Si sale verde, ir a Artifacts → Cinco-Noches-V4-APK, extraer el ZIP e instalar `app-debug.apk`.

Es una compilación de prueba y no se ha validado en un teléfono real. No funciona como una copia idéntica de Five Nights at Freddy's.
